import BerandaUtama from "../../backbone/BerandaUtama";

export default function PICKK() {
  return (
    <div className="">
      <main>
        <BerandaUtama />
      </main>
    </div>
  );
}
