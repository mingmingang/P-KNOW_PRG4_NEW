import React from "react";

const AppContext_test = {materiId : null};

export default AppContext_test;