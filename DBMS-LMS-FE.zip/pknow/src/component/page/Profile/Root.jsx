import ProfileIndex from "./Index";

export default function Notifikasi() {
  return (
    <div>
      <ProfileIndex />
    </div>
  );
}
