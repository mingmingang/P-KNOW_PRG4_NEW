import NotifikasiIndex from "./Index";

export default function Notifikasi() {
  return (
    <div>
      <NotifikasiIndex />
    </div>
  );
}
