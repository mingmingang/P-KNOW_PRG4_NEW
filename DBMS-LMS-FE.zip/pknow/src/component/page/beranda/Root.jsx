import BerandaIndex from "./Index";

export default function Beranda() {
  return (
    <div>
      <BerandaIndex />
    </div>
  );
}
