import "../../../style/Beranda.css";
import BerandaUtama from "../../backbone/BerandaUtama";

export default function PICPKNOW() {
  return (
    <div className="app-container">
      <main>
        <BerandaUtama />
      </main>
    </div>
  );
}
