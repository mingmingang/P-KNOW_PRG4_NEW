import Button from "./Button copy";

export default function Paging({
  pageSize,
  pageCurrent,
  totalData,
  navigation,
}) {
  function generatePageButton(pageSize, pageCurrent, totalData) {
    let totalPage = Math.ceil(totalData / pageSize);
    let segmentPage = Math.ceil(pageCurrent / 10);
    let maxSegmentPage = Math.ceil(totalPage / 10);
    let endPage = segmentPage * 10 > totalPage ? totalPage : segmentPage * 10;
    let pageButton = [];

    if (totalPage > 10 && pageCurrent > 10) {
      pageButton.push(
        <Button
          key={"PageForwardPrev"}
          label="<<"
          classType="custom-button"
          onClick={() => navigation(1)}
        />
      );
      pageButton.push(
        <Button
          key={"PagePrev"}
          label="..."
          classType="custom-button"
          onClick={() => navigation((segmentPage - 1) * 10)}
        />
      );
    }
    for (let i = 1 + (segmentPage - 1) * 10; i <= endPage; i++) {
      pageButton.push(
        <Button
          key={"Page" + i}
          label={i}
          classType={pageCurrent === i ? "primary" : "custom-button"}
          onClick={() => navigation(i)}
        />
      );
    }
    if (totalPage > 10 && segmentPage < maxSegmentPage) {
      pageButton.push(
        <Button
          key={"PageNext"}
          label="..."
          classType="custom-button"
          onClick={() => navigation(segmentPage * 10 + 1)}
        />
      );
      pageButton.push(
        <Button
          key={"PageForwardNext"}
          label=">>"
          classType="custom-button"
          onClick={() => navigation(totalPage)}
        />
      );
    }

    return pageButton;
  }

  return (
    <div className="mt-lg-0 mt-md-0 mt-sm-3 mt-3">
      <div className="input-group">
        {generatePageButton(pageSize, pageCurrent, totalData)}
      </div>
    </div>
  );
}
