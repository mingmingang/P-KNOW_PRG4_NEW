export const APPLICATION_NAME = "Sistem P-KNOW";
export const APPLICATION_ID = "APP59";
export const ROOT_LINK = "http://localhost:5173/";
export const API_LINK = import.meta.env.VITE_API_LINK;
export const FILE_LINK = "http://localhost:5255/api/Upload/GetFile/";
export const BASE_ROUTE = "";
export const PAGE_SIZE = 9;
